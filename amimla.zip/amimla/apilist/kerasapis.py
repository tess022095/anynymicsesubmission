'''
Created on Jul 9, 2018

@author: mislam
'''

from enum import Enum
class KerasAPI():
    def __init__(self):
        self.apis = ['Sequential', 'Dense', 'Activation', 'add', 'compile', 'fit', 'Dropout', 'SGD', 'Conv2D', 'MaxPooling2D', 'Flatten', 'evaluate', 'Embedding', 'LSTM', 'Conv1D', 'MaxPooling1D', 'GlobalAveragePooling1D', 'Input', 'TimeDistributed', 'concatenate', 'Model', 'get_input_shape_at', 'save', 'load_model', 'to_json', 'to_yaml', 'model_from_json', 'model_from_yaml', 'save_weights', 'load_weights', 'EarlyStopping', 'BatchNormalization', 'predict', 'Reshape', 'Permute', 'RepeatVector', 'Lambda', 'ActivityRegularization', 'Masking', 'SpatialDropout1D', 'SpatialDropout2D', 'SpatialDropout3D', 'SeparableConv1D', 'SeparableConv2D', 'Conv2DTranspose', 'Conv3D', 'Cropping1D', 'Cropping2D', 'Cropping3D', 'UpSampling1D', 'UpSampling2D', 'UpSampling3D', 'ZeroPadding1D', 'ZeroPadding2D', 'ZeroPadding3D', 'AveragePooling1D', 'AveragePooling2D', 'AveragePooling3D', 'GlobalMaxPooling1D', 'GlobalAveragePooling1D', 'GlobalMaxPooling2D', 'GlobalAveragePooling2D', 'GlobalMaxPooling3D', 'GlobalAveragePooling3D', 'LocallyConnected1D', 'LocallyConnected2D', 'RNN', 'SimpleRNN', 'GRU', 'ConvLSTM2D', 'SimpleRNNCell', 'GRUCell', 'LSTMCell', 'CuDNNGRU', 'CuDNNLSTM', 'Add', 'Subtract', 'Multiply', 'Average', 'Maximum', 'Concatenate', 'Dot', 'add', 'subtract', 'multiply', 'average', 'maximum', 'concatenate', 'dot', 'LeakyReLU', 'PReLU', 'ELU', 'ThresholdedReLU', 'Softmax', 'ReLU', 'GaussianNoise', 'GaussianDropout', 
                     'AlphaDropout', 'Bidirectional',"texts_to_sequences",'fit_generator','load_img','write_graph','placeholder','read_csv','glorot_uniform','VGGFace','Convolution2D']

    def getApis(self):
        return self.apis
    def hasApiInTheList(self, name):
        return name in self.apis
