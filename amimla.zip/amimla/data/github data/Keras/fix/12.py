shuffle_indexes = np.array(shuffle(range(len(h5_image))))
