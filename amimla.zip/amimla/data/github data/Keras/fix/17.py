model.add(TimeDistributed(Dense(100)))
