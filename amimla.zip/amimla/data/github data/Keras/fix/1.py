# Commit link https://github.com/csvance/deep-connect-four/commit/e97ea051b41bfc20862f8cc6c82fc3ee5ff62b7a
move_input = Input(shape=(7, 4, 2), name='moves')