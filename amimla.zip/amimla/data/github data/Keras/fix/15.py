model = Sequential()
model.add(LSTM(32, input_shape=input_shape)) # 32
model.add(Dense(64, activation='relu')) # 64
model.add(Dropout(0.2))
model.add(Dense(32, activation='relu')) # 32
model.add(Dropout(0.2))
model.add(Dense(self.nb_actions))