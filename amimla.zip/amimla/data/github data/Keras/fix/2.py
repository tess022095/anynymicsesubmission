# Commit link https://github.com/bachelor10/gatherer/commit/30bf3e51bc131ce38be849e9f6bab95f1a55b12c
model = Sequential()
model.add(Conv2D(32, (3, 3), input_shape=(26,26,1), activation="relu"))
model.add(Conv2D(32, (3, 3), activation="relu"))
model.add(MaxPooling2D(pool_size=(2,2)))

model.add(Conv2D(64,(3, 3), activation="relu"))
model.add(Conv2D(64, (3, 3), activation="relu"))
model.add(MaxPooling2D(pool_size=(2,2)))
model.add(Dropout(0.25))
model.add(Flatten())

# Fully connected layer
model.add(Dense(512, activation="relu"))
model.add(Dropout(0.5))
model.add(Dense(39, activation="softmax"))

print("Compiling model")

model.compile(loss=keras.losses.categorical_crossentropy,
              optimizer=keras.optimizers.Adadelta(),
              metrics=['accuracy'])
print("Fitting model")

model.fit_generator(
        train_generator,
        epochs=3,
        validation_data=validation_generator
)