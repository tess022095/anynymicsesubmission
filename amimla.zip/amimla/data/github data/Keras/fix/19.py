layer = Conv2D(num_channels, 1, activation=actv,
                       kernel_initializer=init, padding='same', name=name + 'NIN')