# Commit link https://github.com/Tony607/keras_vggface/commit/e38dfbfcfb005f6e7e6d49ca6724c8c2202b4cfb
vgg_model_conv = VGGFace(include_top=False, input_shape=(224, 224, 3), pooling='avg')
vgg_model = VGGFace(include_top=False, input_shape=(224, 224, 3))