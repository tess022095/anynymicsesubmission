layer = Conv2D(num_channels, 1, activation=actv,
                       kernel_initializer=init, pad='same', name=name + 'NIN')