# Commit link https://github.com/Tony607/keras_vggface/commit/e38dfbfcfb005f6e7e6d49ca6724c8c2202b4cfb
vgg_model_conv = VGGFace(include_top=False, pooling='avg')
vgg_model = VGGFace(include_top=False)