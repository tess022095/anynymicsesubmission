shuffle_indexes = shuffle(range(len(h5_image)))
