outputs = Conv2D(1, 1, activation='relu')(decodeLayer4)
outputs = Flatten()(outputs)
outputs = Dense(572*572*1)(outputs)
outputs = Reshape((572, 572, 1))(outputs)