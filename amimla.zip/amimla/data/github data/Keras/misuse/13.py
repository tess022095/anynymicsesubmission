predict_classes = tf.arg_max(logits_test, axis=1)
