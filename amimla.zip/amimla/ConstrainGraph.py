

class  ConstrainGraph:
    def __init__(self):
        self.past = None
        self.future = None
        self.graph = {}
        self.edges = {}
    def addEdge(self,node1,node2,required = False):
        if node1 not in self.graph:
            self.graph[node1] = []
        self.graph[node1].append(node2)
        self.edges[(node1,node2)] = required
    
        