from os import listdir
from os.path import isfile, join
from detect import Detector
import ast
from mlslice import ProgramSliceVisitor
from slicevisitor import SliceVisitor
import os
import csv

import time
start = time.time()


filepath = "data/examples"
filepath = "data/keras/misuse"
goodkeras = "usage/keras/"
kerasgitcommitdatapath = "data/github data/Keras/misuse"
#filepath = kerasgitcommitdatapath
onlyfiles = [f for f in listdir(filepath) if isfile(join(filepath, f))]
#onlyfiles = ["48155026.txt"]
#31880720.txt
onlyfiles =['PullRepos/fritz-style-transfer-master/convert_to_coreml.py', 'PullRepos/fritz-style-transfer-master/setup.py', 'PullRepos/fritz-style-transfer-master/stylize_image.py', 'PullRepos/fritz-style-transfer-master/style_transfer/fritz_coreml_converter.py', 'PullRepos/fritz-style-transfer-master/style_transfer/layer_converters.py', 'PullRepos/fritz-style-transfer-master/style_transfer/layers.py', 'PullRepos/fritz-style-transfer-master/style_transfer/models.py', 'PullRepos/fritz-style-transfer-master/style_transfer/trainer.py']

#onlyfiles = ["PullRepos/Keras-GAN-master/acgan/acgan.py"]
from apilist.kerasapis import KerasAPI
from precons.keraspr import KerasPRE
from guardcons.kerasguard import KerasGuard
from postcons.keraspost import KerasPOST

keraslist = KerasAPI().getApis()


kerasPres = KerasPRE().getPre()

kerasGc  = KerasGuard().getGC()
kerasPs = KerasPOST().getPost()

#print(keraslist)

"""
for a in keraslist:
    apipath = goodkeras +a+".json"   
    for f in onlyfiles:
        file = filepath +"/"+f
        print("Checking misuse of {0} in {1}".format(a,file))
        detector = Detector(file = file)
        
        #print(file)
        node = detector.getAST()
        detector.readAPISequence(filename = apipath)
        
        vs = ProgramSliceVisitor();
        vs.visit(node)
        layers = vs.getNetwork()
        code = vs.slice(a)
        #print(code)
        sv = SliceVisitor([a])
        sv.visit(node)
        #print(sv.printApis())
        detector.check(sv.printApis())
        #print('Network layers ')
        #for l in layers:
        #    print(l)
"""
   
# Infer some argument value => Majority voting algorithm   
detected = {}
kerasgiturl = "https://github.com/johirbuet/mlslice/blob/master/"
for f in onlyfiles:
        #if f != '34311586.txt':
        #    continue
        #file = filepath +"/"+f
        file = f
        url = kerasgiturl+file
        print("Checking misuse in the file {0}".format(file))
        
        # Here getting all apis of keras api list
        
        for a in keraslist:
            #if a != 'Dense':
            #    continue
            print('Misuse of {0}'.format(a))
            apipath = goodkeras +a+".json"   
            detector = Detector(file = file)
            #print(file)
            node = detector.getAST()
            #print(ast.dump(node))
            detector.readAPISequence(filename = apipath)
            
            vs = ProgramSliceVisitor();
            vs.visit(node)
            layers = vs.getNetwork()
            
            code = vs.slice(a)
            #print("Line 84",code)
            #print(vs.symbols)
            #print(layers)
            #for l in layers:
            #    print(l)
            loads = vs.load
            
            
            if a in kerasPres and a in loads:
                lines = loads[a]#sort()
                lines.sort()
                print("LINE 105",a,loads)
                line = lines[0]
                print(line)
                for pr in kerasPres[a]:
                    # Here i am appending if the precondition doesnt hold
                    #print("PRE",pr,pr in loads,loads[pr])
                    #print(pr,"PR")
                    pr1 = None
                    pr2 = None
                    pr3 = None
                    if '#' in pr:
                        prs = pr.split("#")
                        pr = prs[0]
                        if len(prs) > 1:
                            pr2 = prs[1]
                        if len(prs) > 2:
                            pr3 = prs[2]
                    #print(pr,pr1,pr2,pr3)
                    if pr in loads:
                        prlines = loads[pr]
                        prlines.sort()
                        prline = prlines[0]
                        #if prlines
                        # Here i am appending to detected if the pre condition doesn't hold
                        if prline > line:
                            res = {}
                            res['api'] = a
                            res['message'] = "{0} api needs to be called before {1} is called".format(pr,a)
                            res['count'] = 1
                            if url not in detected:
                                detected[url] = []
                            detected[url].append(res)
                        elif pr2 != None and pr2 in loads:
                            prlines = loads[pr2]
                            prlines.sort()
                            prline = prlines[0]
                            #if prlines
                            # Here i am appending to detected if the pre condition doesn't hold
                            if prline > line:
                                res = {}
                                res['api'] = a
                                res['message'] = "{0} api needs to be called before {1} is called".format(pr2,a)
                                res['count'] = 1
                                if url not in detected:
                                    detected[url] = []
                                detected[url].append(res)
                        elif pr3 != None and pr3 in loads:
                            prlines = loads[pr3]
                            prlines.sort()
                            prline = prlines[0]
                            #if prlines
                            # Here i am appending to detected if the pre condition doesn't hold
                            if prline > line:
                                res = {}
                                res['api'] = a
                                res['message'] = "{0} api needs to be called before {1} is called".format(pr2,a)
                                res['count'] = 1
                                if url not in detected:
                                    detected[url] = []
                                detected[url].append(res)
                    elif pr2 != None and pr2 in loads:
                            prlines = loads[pr2]
                            prlines.sort()
                            prline = prlines[0]
                            #if prlines
                            # Here i am appending to detected if the pre condition doesn't hold
                            if prline > line:
                                res = {}
                                res['api'] = a
                                res['message'] = "{0} api needs to be called before {1} is called".format(pr2,a)
                                res['count'] = 1
                                if url not in detected:
                                    detected[url] = []
                                detected[url].append(res)
                            elif pr3 != None and pr3 in loads:
                                prlines = loads[pr3]
                                prlines.sort()
                                prline = prlines[0]
                                #if prlines
                                # Here i am appending to detected if the pre condition doesn't hold
                                if prline > line:
                                    res = {}
                                    res['api'] = a
                                    res['message'] = "{0} api needs to be called before {1} is called".format(pr2,a)
                                    res['count'] = 1
                                    if url not in detected:
                                        detected[url] = []
                                    detected[url].append(res)
                    elif pr3 != None and pr3 in loads:
                            prlines = loads[pr3]
                            prlines.sort()
                            prline = prlines[0]
                            #if prlines
                            # Here i am appending to detected if the pre condition doesn't hold
                            if prline > line:
                                res = {}
                                res['api'] = a
                                res['message'] = "{0} api needs to be called before {1} is called".format(pr2,a)
                                res['count'] = 1
                                if url not in detected:
                                    detected[url] = []
                                detected[url].append(res)
                    else:
                        res = {}
                        res['api'] = a
                        res['message'] = "{0} api needs to be called before {1} is called".format(pr,a)
                        res['count'] = 1
                        if url not in detected:
                                detected[url] = []
                        detected[url].append(res)
            # Post
            if a in kerasPs and a in loads:
                print("LINE 124 ",loads)
                lines = loads[a]#sort()
                lines.sort()
                #print("Lines",a,loads)
                line = lines[0]
                for pr in kerasPs[a]:
                    # Here i am appending if the precondition doesnt hold
                    pr1 = None
                    pr2 = None
                    if "&" in pr:
                        pr1,pr2 = pr.split("&")
                        pr = pr1
                    if pr in loads:
                        prlines = loads[pr]
                        prlines.sort()
                        prline = prlines[-1]
                        # Here i am appending to detected if the pre condition doesn't hold
                        if prline < line:
                            res = {}
                            res['api'] = a
                            res['message'] = "{0} api needs to be called after {1} is called".format(pr,a)
                            res['count'] = 1
                            if url not in detected:
                                detected[url] = []
                            detected[url].append(res)
                    elif pr2 != None and pr2 in loads:
                        pr = pr2
                        prlines = loads[pr]
                        prlines.sort()
                        prline = prlines[-1]
                        # Here i am appending to detected if the pre condition doesn't hold
                        if prline < line:
                            res = {}
                            res['api'] = a
                            res['message'] = "{0} api needs to be called after {1} is called".format(pr,a)
                            res['count'] = 1
                            if url not in detected:
                                detected[url] = []
                            detected[url].append(res)
                    else:
                        res = {}
                        res['api'] = a
                        res['message'] = "{0} api needs to be called after {1} is called".format(pr,a)
                        res['count'] = 1
                        if url not in detected:
                                detected[url] = []
                        detected[url].append(res)
                        
            #print("Load",vs.load)
            #print(code)
            sv = SliceVisitor([a],customobject = vs.customobject)
            print(file)
            sv.visit(node)
            print("ARG VALUES",sv.getArgValues(),sv.values,sv.apivals)
            #if a == 'Activation':
            #    print(code)
            #    print("Line 64",sv.printApis())
            #print("Line 64",sv.printApis())
            
            apicall = sv.printApis()
            print("Custom objeccts", vs.customobject)   
            #print("Line 122 Evaluate Detect",apicall)
            # Here I am finding the misuse cases for the LSTM APIS
            if a == "LSTM":
                alllsms = []
                ok = True
                print("LSTM START",sv.getArgValues(),apicall)
                for key in apicall:
                    if key[:-1] == 'LSTM' or key[:-1] == "TimeDistributed":
                        alllsms.append(key)
                """
                if len(alllsms) == 1:
                    pass
                    if "return_sequences" not in apicall[key]:
                        message = "{0} layer at line {1}  {2} should have return sequences True".format(a,apicall[key]['lineno'],apicall[key]['statement'])
                        res = {}
                        res['api'] = a
                        res['message'] = message
                        res['count'] = 1
                        if url not in detected:
                            detected[url] = []
                        detected[url].append(res)
                """
                print(sv.getArgValues(),"206")
                for key in alllsms[0:-1]:
                    print(apicall[key])
                    print('return_sequences' in sv.getArgValues()[key])
                    if key[:-1] == 'LSTM' and "return_sequences" not in apicall[key]:
                        message = "{0} layer at line {1}  {2} should have return sequences True".format(a,apicall[key]['lineno'],apicall[key]['statement'])
                        res = {}
                        res['api'] = a
                        res['message'] = message
                        res['count'] = 1
                        if url not in detected:
                            detected[url] = []
                        detected[url].append(res)
                    elif 'return_sequences' in sv.getArgValues()[key] and key[:-1] == 'LSTM' and (sv.getArgValues()[key]['return_sequences'] == False or sv.getArgValues()[key]['return_sequences'] == "False"):
                        message = "{0} layer at line {1}  {2} should have return sequences True".format(a,apicall[key]['lineno'],apicall[key]['statement'])
                        res = {}
                        res['api'] = a
                        res['message'] = message
                        res['count'] = 1
                        if url not in detected:
                            detected[url] = []
                        detected[url].append(res)
                    else:
                        print(sv.getArgValues(),"LINE 225")
            
            #Check input_shape given backend
            for apikey in apicall:
                
                apibody = apicall[apikey]
                apivalues = sv.getArgValues()[apikey]
                if a == "Conv2D" or a == "ZeroPadding2D":
                    backend = sv.backend
                    if "input_shape" in apivalues:
                        print(apivalues["input_shape"],file, apivalues,apibody)
                        #print(apivalues["input_shape"], "Shape")
                        if backend == "TF" and "arg1" in apivalues["input_shape"] and (apivalues["input_shape"]["arg1"] == 3  or apivalues["input_shape"]["arg1"] == 1):
                            message = "In {0} at Line {1} {2} You are having channel first but background looks tensorflow".format(a,apicall[apikey]['lineno'],apicall[apikey]['statement'])
                            res = {}
                            res['api'] = a
                            res['message'] = message
                            res['count'] = 1
                            if url not in detected:
                                detected[url] = []
                            detected[url].append(res)
                            break
                        elif backend == "TH" and (apivalues["input_shape"]["arg1"] != 1  or apivalues["input_shape"]["arg1"] != 3):
                            message = "In {0} at Line {1} {2} You are nt having channel first but background looks Theano".format(a,apicall[apikey]['lineno'],apicall[apikey]['statement'])
                            res = {}
                            res['api'] = a
                            res['message'] = message
                            res['count'] = 1
                            if url not in detected:
                                detected[url] = []
                            detected[url].append(res)
                            break
                            
            # Print the guard condition violation. Here only the misuses related to guard condition violations are added
            for apikey in apicall:
                
                apibody = apicall[apikey]
                apivalues = sv.getArgValues()[apikey]
                if a == 'compile':
                    
                    if 'metrics' in apibody:
                        if 'metrics' in apivalues:
                            for mkey in apivalues['metrics']:
                                metricval = apivalues['metrics'][mkey]
                                #print("compile", metricval,vs.customobject)
                                objs = vs.customobject
                                if apibody['metrics'][mkey] == "UserMethod"  and metricval not in objs and ('load_model' in loads or 'load_weights' in loads):
                                    message = "In {0} at Line {1} {2} {3} is an user defined metric but is not passed as custome objects".format(a,apicall[apikey]['lineno'],apicall[apikey]['statement'],metricval)
                                    res = {}
                                    res['api'] = a
                                    res['message'] = message
                                    res['count'] = 1
                                    if url not in detected:
                                        detected[url] = []
                                    detected[url].append(res)
                if a == "Embedding":
                    values = sv.getArgValues()
                    if "arg0" in apibody or "input_dim" in apibody:
                        
                        if "input_dim" in apibody:
                            if 'input_dim' not in apivalues:
                                print(apivalues,"nbword not found",apibody,file)
                                continue
                            nbword = apivalues["input_dim"]
                            for val in sv.values:
                                if nbword == sv.values[val]:
                                    message = "In {0} at Line {1} {2} input_dim should be 1 more than the vocabulary size. But looks like you are having same as vocabulary size {3}".format(a,apicall[apikey]['lineno'],apicall[apikey]['statement'],nbword)
                                    res = {}
                                    res['api'] = a
                                    res['message'] = message
                                    res['count'] = 1
                                    if url not in detected:
                                        detected[url] = []
                                    detected[url].append(res)
                                    break
                            
                        elif "arg0" in apibody:
                            print(apivalues)
                            if "arg0" in apibody:
                                if 'arg0' not in apivalues:
                                    print(apivalues,"nbword not found",apibody,file)
                                    continue
                            nbword = apivalues["arg0"]
                            for val in sv.values:
                                if nbword == sv.values[val]:
                                    message = "In {0} at Line {1} {2} arg0 should be 1 more than the vocabulary size. But looks like you are having same as vocabulary size {3}".format(a,apicall[apikey]['lineno'],apicall[apikey]['statement'],nbword)
                                    res = {}
                                    res['api'] = a
                                    res['message'] = message
                                    res['count'] = 1
                                    if url not in detected:
                                        detected[url] = []
                                    detected[url].append(res)
                                    break
                ok = False
                message = []
                if a in kerasGc:
                    values = sv.getArgValues()
                    curval = values[apikey]
                    print("Arg values", values)
                    passed = True
                    for gc in kerasGc[a]:
                        passed = True
                        print("LINE 172",len(gc))
                        if len(gc) == 2:
                            first = gc[0]
                            arg = first["arg"]
                            op = first["op"]
                            val = first["val"]
                            cond1 = False
                            if op == ">":
                                if arg in curval and arg in apibody:
                                    cond1 = (curval[arg] > val)
                            elif op == "==":
                                if arg in curval and arg in apibody:
                                    cond1 = (curval[arg] == val)
                            elif op == "!=":
                                if arg in curval and arg in apibody:
                                    cond1 = (curval[arg] != val)
                            cond2 = False
                            if cond1 == True:
                                second = gc[1]
                                arg2 = second["arg"]
                                op2 = second["op"]
                                val2 = second["val"]
                                cond2 = False
                                if op2 == ">":
                                    if arg2 in curval and arg2 in apibody:
                                        cond2 = (curval[arg2] > val2)
                                    else:
                                        cond3 = True
                                elif op2 == "==":
                                    if arg2 in curval and arg2 in apibody:
                                        cond2 = (curval[arg2] == val2)
                                    else:
                                        cond2 = True
                                elif op2 == "!=":
                                    if arg2 in curval and arg2 in apibody:
                                        cond2 = (curval[arg2] != val2)
                                    else:
                                        cond2 = True
                                if cond2 == False:
                                    ms = "Given {0} is {1}, {2} should not be {3}".format(arg,val,arg2,val2)
                                    message.append(ms)
                                passed = cond1 and cond2
                            else:
                                passed = True
                                #ms = " {0} should not be {1}".format(arg,val)
                                #message.append(ms)
                            ok = ok or passed
                        if len(gc) == 1:
                            first = gc[0]
                            arg = first["arg"]
                            op = first["op"]
                            val = first["val"]
                            cond1 = False
                            if op == ">":
                                if arg in curval and arg in apibody:
                                    cond1 = (curval[arg] > val)
                            elif op == "==":
                                if arg in curval and arg in apibody:
                                    cond1 = (curval[arg] == val)
                            elif op == "!=":
                                if arg in curval and arg in apibody:
                                    cond1 = (curval[arg] != val)
                            if cond1 == False:
                                passed = True
                                ms = " {0} should not be {1}".format(arg,val)
                                message.append(ms)
                            ok = ok or passed
                        """
                        for dic in gc:
                            # For each dic it will be and contidion
                            print("LINE 174", dic)
                            #for key in dic:
                            arg = dic["arg"]
                            op = dic["op"]
                            val = dic["val"]
                            if op == ">":
                                if arg in curval and arg in apibody:
                                    passed = passed and (curval[arg] > val)
                                    if passed == False:
                                        ms = "{0} should not be {1} at api {2} line {3}".format(arg,val,a,apibody['lineno'])
                                        if ms not in message:
                                            message.append(ms)
                            if op == "!=":
                                if arg in curval and arg in apibody:
                                    passed = passed and (curval[arg] != val)
                                    if passed == False:
                                        ms = "{0} should not be {1} at api {2} line {3}".format(arg,val,a,apibody['lineno'])
                                        if ms not in message:
                                            message.append(ms)
                            if op == "==":
                                if arg in curval and arg in apibody:
                                    #print("VAL = ",val)
                                    #print("CURVAL ",curval[arg])
                                    #print("LINE 193",curval[arg] == val)
                                    passed = passed and (curval[arg] == val)
                                    if passed == False:
                                        ms = "{0} should not be {1} at api {2} line {3}".format(arg,val,a,apibody['lineno'])
                                        if ms not in message:
                                            message.append(ms)
                            #print("LINE 201", passed)
                            """
                            
                    # If guard condition doesn't hold
                    if ok == False:
                        res = {}
                        res['api'] = a
                        res['message'] = " and ".join(message)
                        res['count'] = 1
                        if url not in detected:
                            detected[url] = []
                        detected[url].append(res)
            apiname = None
            lineNo = None
            statement = None
            for key in apicall:
                apidef = apicall[key]
                apiname = apidef['apiname']
                lineNo = apidef['lineno']
                statement = apidef['statement']
                # Here i am passing the full information
                detector.check({key:apidef},apikey = key)
                res = detector.getResult()
                #print("Line 212",res)
                if res['count'] > 0:
                    res['api'] = a
                    res['message'] = "Misuse of the {0} API at line {1} in the code {2}".format(apiname,lineNo, statement)
                    url = kerasgiturl+res['filename']
                    if url not in detected:
                        detected[url] = []
                    detected[url].append(res)
                apidef.pop('apiname',None)
                apidef.pop('lineno',None)
                apidef.pop('statement',None)
                print("API def is \"{0}\" of API \"{1}\" at line {2} ".format(apidef,apiname,lineNo))
            #print(apicall)
            #detector.check(sv.printApis())
            #res = detector.getResult()
            #res['api'] = a
            #res['message'] = "Misuse of the {0} API at line {1} in the code {2}".format(apiname,lineNo, statement)
            #detected.append(res)
        #print('Network layers ')
        #for l in layers:
        #    print(l)    
i = 1

kerasres = "results/kerasres2.csv"



keras = open(kerasres, "w")
writer = csv.writer(keras)
writer.writerow(["URL", "Message"])
totalmisuse = 0

# Commenting out the write part for 
#print("Line 244",detected)
for url in detected:
    misuse = detected[url]
    allmisuses = [url]
    for d in misuse:
        
        if d['count'] > 0:
            print(i,d['message'],d)
            if 'nonmatches' in d:
                print(d['nonmatches'])
            allmisuses.append(d['message'])
            i = i + 1
            totalmisuse += d['count']
   
    if len(allmisuses) > 1:
        writer.writerow(allmisuses)

        
    #print(detector.callseq)
keras.close()
print("Total detected misuses ",totalmisuse)    

end = time.time()
print(end - start)
print(len(onlyfiles))
    