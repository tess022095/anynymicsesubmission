from os import listdir
from os.path import isfile, join
from detect import Detector
import ast
from mlslice import ProgramSliceVisitor
from slicevisitor import SliceVisitor
import os
import csv

filepath = "data/examples"
filepath = "data/sklearn/misuse"
goodsklearn = "usage/sklearn/"
onlyfiles = [f for f in listdir(filepath) if isfile(join(filepath, f))]
#onlyfiles = ["31880720.txt"]

from apilist.sklearnapi import SklearnAPI

sklearnapis = SklearnAPI().getApis()




"""
for a in keraslist:
    apipath = goodkeras +a+".json"   
    for f in onlyfiles:
        file = filepath +"/"+f
        print("Checking misuse of {0} in {1}".format(a,file))
        detector = Detector(file = file)

        #print(file)
        node = detector.getAST()
        detector.readAPISequence(filename = apipath)

        vs = ProgramSliceVisitor();
        vs.visit(node)
        layers = vs.getNetwork()
        code = vs.slice(a)
        #print(code)
        sv = SliceVisitor([a])
        sv.visit(node)
        #print(sv.printApis())
        detector.check(sv.printApis())
        #print('Network layers ')
        #for l in layers:
        #    print(l)
"""

# Infer some argument value => Majority voting algorithm
detected = {}
tfgiturl = "https://github.com/johirbuet/mlslice/blob/master/"
for f in onlyfiles:
    file = filepath + "/" + f
    print("Checking misuse in the file {0}".format(file))
    for a in sklearnapis:
        print('Misuse of {0}'.format(a))
        apipath = goodsklearn + a + ".json"
        detector = Detector(file=file)
        # print(file)
        node = detector.getAST()
        # print(ast.dump(node))
        detector.readAPISequence(filename=apipath)

        vs = ProgramSliceVisitor();
        vs.visit(node)
        layers = vs.getNetwork()
        code = vs.slice(a)
        # print(code)
        sv = SliceVisitor([a])
        sv.visit(node)
        # if a == 'Activation':
        #    print(code)
        #    print("Line 64",sv.printApis())
        # print("Line 64",sv.printApis())
        apicall = sv.printApis()
        apiname = None
        lineNo = None
        statement = None
        for key in apicall:
            apidef = apicall[key]
            apiname = apidef['apiname']
            lineNo = apidef['lineno']
            statement = apidef['statement']
            detector.check({key: apidef})
            res = detector.getResult()
            res['api'] = a
            res['message'] = "Misuse of the {0} API at line {1} in the code {2}".format(apiname, lineNo, statement)
            url = tfgiturl + res['filename']
            if url not in detected:
                detected[url] = []
            detected[url].append(res)
            apidef.pop('apiname', None)
            apidef.pop('lineno', None)
            apidef.pop('statement', None)
        print(apicall)
        # detector.check(sv.printApis())
        # res = detector.getResult()
        # res['api'] = a
        # res['message'] = "Misuse of the {0} API at line {1} in the code {2}".format(apiname,lineNo, statement)
        # detected.append(res)
    # print('Network layers ')
    # for l in layers:
    #    print(l)
i = 1

sklearnres = "results/sklearn.csv"
totalmisuse = 0
tf = open(sklearnres, "w")
writer = csv.writer(tf)
writer.writerow(["URL", "Message"])

for url in detected:
    misuse = detected[url]
    allmisuses = [url]
    for d in misuse:
        if d['count'] > 0:
            print(i, d['message'], d)
            allmisuses.append(d['message'])
            i = i + 1
            totalmisuse += d['count']

    if len(allmisuses) > 1:
        writer.writerow(allmisuses)

    # print(detector.callseq)
tf.close()

print('Total misuse detected = {0}'.format(totalmisuse))
