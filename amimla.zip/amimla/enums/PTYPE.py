'''
Created on Jul 9, 2018

@author: mislam
'''

from enum import Enum

class PTYPE(Enum):
    INT = 1
    FLOAT = 2
    STRING = 3
