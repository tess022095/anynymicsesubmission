from apilist.kerasapis import KerasAPI
from apilist.tfapis import TFAPI

tflist = TFAPI().getApis()
keraslist = KerasAPI().getApis()
tflist = set(tflist)
print("Total TF", len(tflist))
keraslist = set(keraslist)
print("Total Keras", len(keraslist))