from os import listdir
from os.path import isfile, join
from detect import Detector
import ast
from mlslice import ProgramSliceVisitor
from slicevisitor import SliceVisitor
import os
import csv

import random
print(random.randint(0,9))


import time
start = time.time()

filepath = "data/examples"
filepath = "data/tf/misuse"
goodtf = "usage/tf/"
onlyfiles = [f for f in listdir(filepath) if isfile(join(filepath, f))]
#onlyfiles = ["47410778.txt"]

#onlyfiles = ['PullRepos/TensorFlowOnSpark-master/examples/model_export.py', 'PullRepos/TensorFlowOnSpark-master/examples/cifar10/cifar10.py', 'PullRepos/TensorFlowOnSpark-master/examples/cifar10/cifar10_eval.py', 'PullRepos/TensorFlowOnSpark-master/examples/cifar10/cifar10_input.py', 'PullRepos/TensorFlowOnSpark-master/examples/cifar10/cifar10_input_test.py', 'PullRepos/TensorFlowOnSpark-master/examples/cifar10/cifar10_multi_gpu_train.py', 'PullRepos/TensorFlowOnSpark-master/examples/cifar10/cifar10_train.py', 'PullRepos/TensorFlowOnSpark-master/examples/criteo/spark/criteo_dist.py', 'PullRepos/TensorFlowOnSpark-master/examples/imagenet/inception/dataset.py', 'PullRepos/TensorFlowOnSpark-master/examples/imagenet/inception/flowers_eval.py', 'PullRepos/TensorFlowOnSpark-master/examples/imagenet/inception/flowers_train.py', 'PullRepos/TensorFlowOnSpark-master/examples/imagenet/inception/image_processing.py', 'PullRepos/TensorFlowOnSpark-master/examples/imagenet/inception/imagenet_distributed_train.py', 'PullRepos/TensorFlowOnSpark-master/examples/imagenet/inception/imagenet_distributed_train_pipeline.py', 'PullRepos/TensorFlowOnSpark-master/examples/imagenet/inception/imagenet_eval.py', 'PullRepos/TensorFlowOnSpark-master/examples/imagenet/inception/imagenet_train.py', 'PullRepos/TensorFlowOnSpark-master/examples/imagenet/inception/inception_distributed_train.py', 'PullRepos/TensorFlowOnSpark-master/examples/imagenet/inception/inception_eval.py', 'PullRepos/TensorFlowOnSpark-master/examples/imagenet/inception/inception_export.py', 'PullRepos/TensorFlowOnSpark-master/examples/imagenet/inception/inception_model.py', 'PullRepos/TensorFlowOnSpark-master/examples/imagenet/inception/inception_train.py', 'PullRepos/TensorFlowOnSpark-master/examples/imagenet/inception/data/build_image_data.py', 'PullRepos/TensorFlowOnSpark-master/examples/imagenet/inception/data/build_imagenet_data.py', 'PullRepos/TensorFlowOnSpark-master/examples/imagenet/inception/slim/collections_test.py', 'PullRepos/TensorFlowOnSpark-master/examples/imagenet/inception/slim/inception_model.py', 'PullRepos/TensorFlowOnSpark-master/examples/imagenet/inception/slim/inception_test.py', 'PullRepos/TensorFlowOnSpark-master/examples/imagenet/inception/slim/losses.py', 'PullRepos/TensorFlowOnSpark-master/examples/imagenet/inception/slim/losses_test.py', 'PullRepos/TensorFlowOnSpark-master/examples/imagenet/inception/slim/ops.py', 'PullRepos/TensorFlowOnSpark-master/examples/imagenet/inception/slim/ops_test.py', 'PullRepos/TensorFlowOnSpark-master/examples/imagenet/inception/slim/scopes_test.py', 'PullRepos/TensorFlowOnSpark-master/examples/imagenet/inception/slim/variables.py', 'PullRepos/TensorFlowOnSpark-master/examples/imagenet/inception/slim/variables_test.py', 'PullRepos/TensorFlowOnSpark-master/examples/mnist/mnist_data_setup.py', 'PullRepos/TensorFlowOnSpark-master/examples/mnist/estimator/mnist_estimator.py', 'PullRepos/TensorFlowOnSpark-master/examples/mnist/keras/mnist_mlp.py', 'PullRepos/TensorFlowOnSpark-master/examples/mnist/keras/mnist_mlp_estimator.py', 'PullRepos/TensorFlowOnSpark-master/examples/mnist/spark/mnist_dist.py', 'PullRepos/TensorFlowOnSpark-master/examples/mnist/spark/mnist_dist_dataset.py', 'PullRepos/TensorFlowOnSpark-master/examples/mnist/spark/mnist_dist_pipeline.py', 'PullRepos/TensorFlowOnSpark-master/examples/mnist/spark/mnist_spark.py', 'PullRepos/TensorFlowOnSpark-master/examples/mnist/spark/mnist_spark_dataset.py', 'PullRepos/TensorFlowOnSpark-master/examples/mnist/spark/mnist_spark_pipeline.py', 'PullRepos/TensorFlowOnSpark-master/examples/mnist/streaming/mnist_dist.py', 'PullRepos/TensorFlowOnSpark-master/examples/mnist/tf/mnist_dist.py', 'PullRepos/TensorFlowOnSpark-master/examples/mnist/tf/mnist_dist_dataset.py', 'PullRepos/TensorFlowOnSpark-master/examples/mnist/tf/mnist_dist_pipeline.py', 'PullRepos/TensorFlowOnSpark-master/examples/mnist/tf/mnist_spark_pipeline.py', 'PullRepos/TensorFlowOnSpark-master/examples/slim/download_and_convert_data.py', 'PullRepos/TensorFlowOnSpark-master/examples/slim/eval_image_classifier.py', 'PullRepos/TensorFlowOnSpark-master/examples/slim/train_image_classifier.py', 'PullRepos/TensorFlowOnSpark-master/examples/slim/datasets/cifar10.py', 'PullRepos/TensorFlowOnSpark-master/examples/slim/datasets/dataset_utils.py', 'PullRepos/TensorFlowOnSpark-master/examples/slim/datasets/download_and_convert_cifar10.py', 'PullRepos/TensorFlowOnSpark-master/examples/slim/datasets/download_and_convert_flowers.py', 'PullRepos/TensorFlowOnSpark-master/examples/slim/datasets/download_and_convert_mnist.py', 'PullRepos/TensorFlowOnSpark-master/examples/slim/datasets/flowers.py', 'PullRepos/TensorFlowOnSpark-master/examples/slim/datasets/imagenet.py', 'PullRepos/TensorFlowOnSpark-master/examples/slim/datasets/mnist.py', 'PullRepos/TensorFlowOnSpark-master/examples/slim/deployment/model_deploy.py', 'PullRepos/TensorFlowOnSpark-master/examples/slim/deployment/model_deploy_test.py', 'PullRepos/TensorFlowOnSpark-master/examples/slim/nets/alexnet.py', 'PullRepos/TensorFlowOnSpark-master/examples/slim/nets/alexnet_test.py', 'PullRepos/TensorFlowOnSpark-master/examples/slim/nets/cifarnet.py', 'PullRepos/TensorFlowOnSpark-master/examples/slim/nets/inception_resnet_v2.py', 'PullRepos/TensorFlowOnSpark-master/examples/slim/nets/inception_resnet_v2_test.py', 'PullRepos/TensorFlowOnSpark-master/examples/slim/nets/inception_utils.py', 'PullRepos/TensorFlowOnSpark-master/examples/slim/nets/inception_v1.py', 'PullRepos/TensorFlowOnSpark-master/examples/slim/nets/inception_v1_test.py', 'PullRepos/TensorFlowOnSpark-master/examples/slim/nets/inception_v2.py', 'PullRepos/TensorFlowOnSpark-master/examples/slim/nets/inception_v2_test.py', 'PullRepos/TensorFlowOnSpark-master/examples/slim/nets/inception_v3.py', 'PullRepos/TensorFlowOnSpark-master/examples/slim/nets/inception_v3_test.py', 'PullRepos/TensorFlowOnSpark-master/examples/slim/nets/inception_v4.py', 'PullRepos/TensorFlowOnSpark-master/examples/slim/nets/inception_v4_test.py', 'PullRepos/TensorFlowOnSpark-master/examples/slim/nets/lenet.py', 'PullRepos/TensorFlowOnSpark-master/examples/slim/nets/nets_factory.py', 'PullRepos/TensorFlowOnSpark-master/examples/slim/nets/nets_factory_test.py', 'PullRepos/TensorFlowOnSpark-master/examples/slim/nets/overfeat.py', 'PullRepos/TensorFlowOnSpark-master/examples/slim/nets/overfeat_test.py', 'PullRepos/TensorFlowOnSpark-master/examples/slim/nets/resnet_utils.py', 'PullRepos/TensorFlowOnSpark-master/examples/slim/nets/resnet_v1.py', 'PullRepos/TensorFlowOnSpark-master/examples/slim/nets/resnet_v1_test.py', 'PullRepos/TensorFlowOnSpark-master/examples/slim/nets/resnet_v2.py', 'PullRepos/TensorFlowOnSpark-master/examples/slim/nets/resnet_v2_test.py', 'PullRepos/TensorFlowOnSpark-master/examples/slim/nets/vgg.py', 'PullRepos/TensorFlowOnSpark-master/examples/slim/nets/vgg_test.py', 'PullRepos/TensorFlowOnSpark-master/examples/slim/preprocessing/cifarnet_preprocessing.py', 'PullRepos/TensorFlowOnSpark-master/examples/slim/preprocessing/inception_preprocessing.py', 'PullRepos/TensorFlowOnSpark-master/examples/slim/preprocessing/lenet_preprocessing.py', 'PullRepos/TensorFlowOnSpark-master/examples/slim/preprocessing/preprocessing_factory.py', 'PullRepos/TensorFlowOnSpark-master/examples/slim/preprocessing/vgg_preprocessing.py']

#filepath = "" # To be commented
indices = random.sample(range(124), 10)
print(indices)
from apilist.tfapis import TFAPI
from guardcons.tfguard import TFGuard
from postcons.tfpost import TFPOST
tflist = TFAPI().getApis()
tflist = set(tflist)

fff = []
for i in range(30, len(onlyfiles)):
    fff.append(onlyfiles[i])
#indices = [7,8,9,10,11,12]
#for i in indices:
#    fff.append(onlyfiles[i])

tfPs = TFPOST().getPost()
# print(keraslist)

tfGc  = TFGuard().getGC()

# Infer some argument value => Majority voting algorithm
detected = {}
tfgiturl = "https://github.com/johirbuet/mlslice/blob/master/"
for f in onlyfiles:
    if f == "tf_location.xlsx":
        continue
    file = filepath + "/" + f
    #file = f # To be commented
    print("Checking misuse in the file {0}".format(file))
    for a in tflist:
        print('Misuse of {0}'.format(a))
        apipath = goodtf + a + ".json"
        detector = Detector(file=file)
        # print(file)
        node = detector.getAST()
        # print(ast.dump(node))
        detector.readAPISequence(filename=apipath)

        vs = ProgramSliceVisitor()
        vs.visit(node)
        layers = vs.getNetwork()
        code = vs.slice(a)
        # print(code)
        sv = SliceVisitor([a])
        sv.visit(node)
        # if a == 'Activation':
        #    print(code)
        #    print("Line 64",sv.printApis())
        # print("Line 64",sv.printApis())
        apicall = sv.printApis()
        customobjects = vs.customobject
        print("CUSTOM OBJECTS", customobjects)
        feedobjects = vs.feedobjects
        print('FEED OBJECTS',feedobjects)
        placeholders = vs.placeholders
        print("PLACEHOLDERS",placeholders)
        apiname = None
        lineNo = None
        statement = None
        loads = vs.load
        if a in tfPs and a in loads:
                print("LINE 124 ",loads)
                lines = loads[a]#sort()
                lines.sort()
                #print("Lines",a,loads)
                line = lines[0]
                for pr in tfPs[a]:
                    # Here i am appending if the precondition doesnt hold
                    pr1 = None
                    pr2 = None
                    if "&" in pr:
                        pr1,pr2 = pr.split("&")
                        pr = pr1
                    if pr in loads:
                        prlines = loads[pr]
                        prlines.sort()
                        prline = prlines[-1]
                        # Here i am appending to detected if the pre condition doesn't hold
                        if prline < line:
                            res = {}
                            res['api'] = a
                            res['message'] = "{0} api needs to be called after {1} is called".format(pr,a)
                            res['count'] = 1
                            if url not in detected:
                                detected[url] = []
                            detected[url].append(res)
                    elif pr2 != None and pr2 in loads:
                        pr = pr2
                        prlines = loads[pr]
                        prlines.sort()
                        prline = prlines[-1]
                        # Here i am appending to detected if the pre condition doesn't hold
                        if prline < line:
                            res = {}
                            res['api'] = a
                            res['message'] = "{0} api needs to be called after {1} is called".format(pr,a)
                            res['count'] = 1
                            if url not in detected:
                                detected[url] = []
                            detected[url].append(res)
                    else:
                        res = {}
                        res['api'] = a
                        res['message'] = "{0} api needs to be called after {1} is called".format(pr,a)
                        res['count'] = 1
                        if url not in detected:
                                detected[url] = []
                        detected[url].append(res)
        if a == 'placeholder':
            for p in placeholders:
                if p not in feedobjects:
                    res = {}
                    res['api'] = a
                    res['message'] = "Misuse of the {0} API. The placeholder variable {1} is neever feed".format(a,p)
                    res['count'] = 1
                    url = tfgiturl + file
                    if url not in detected:
                        detected[url] = []
                    detected[url].append(res)

        sessionstart = vs.sessionstart
        sessionstartLine = vs.sessionstartLine
        sessionclose = vs.sessionclose
        sessioncloseLine = vs.sessioncloseLine
        for key in apicall:
            apidef = apicall[key]
            apiname = apidef['apiname']
            lineNo = apidef['lineno']
            statement = apidef['statement']
            detector.check({key: apidef},apikey = key)
            res = detector.getResult()
            res['api'] = a
            res['message'] = "Misuse of the {0} API at line {1} in the code {2}".format(apiname, lineNo, statement)
            url = tfgiturl + res['filename']
            if url not in detected:
                detected[url] = []
            detected[url].append(res)
            apidef.pop('apiname', None)
            apidef.pop('lineno', None)
            apidef.pop('statement', None)
            if a == 'run' or a == 'eval':
                if sessionstart == False:
                    res = {}
                    res['api'] = a
                    res['message'] = "{0} called without starting the session".format(a)
                    res['count'] = 1
                    if url not in detected:
                        detected[url] = []
                    detected[url].append(res)
        print(apicall)
        if len(apicall) > 0 and  ( a =='InteractiveSession') and code != None and sessionstart == True and sessionclose == False:
            res = {}
            res['api'] = a
            url = tfgiturl + file
            res['message'] = "{0} started at Line {1} but never closed".format(a,sessionstartLine)
            res['count'] = 1
            if url not in detected:
                detected[url] = []
            detected[url].append(res)
        elif len(apicall) > 0 and  a =='Session' and code!= None and sessionstart == True and sessionclose == False:
            res = {}
            res['api'] = a
            url = tfgiturl + file
            res['message'] = "{0} started at Line {1} but never closed".format(a,sessionstartLine)
            res['count'] = 1
            if url not in detected:
                detected[url] = []
            detected[url].append(res)
        # detector.check(sv.printApis())
        # res = detector.getResult()
        # res['api'] = a
        # res['message'] = "Misuse of the {0} API at line {1} in the code {2}".format(apiname,lineNo, statement)
        # detected.append(res)
    # print('Network layers ')
    # for l in layers:
    #    print(l)
i = 1

tfres = "results/tensorflow4.csv"
totalmisuse = 0
tf = open(tfres, "w")
writer = csv.writer(tf)
writer.writerow(["URL", "Message"])

print(len(detected))
for url in detected:
    misuse = detected[url]
    allmisuses = [url]
    for d in misuse:
        if d['count'] > 0:
            print(i, d['message'], d)
            allmisuses.append(d['message'])
            i = i + 1
            totalmisuse += d['count']

    if len(allmisuses) > 1:
        writer.writerow(allmisuses)

    # print(detector.callseq)
tf.close()

print('Total misuse detected = {0}'.format(totalmisuse))


end = time.time()
print(end - start)
