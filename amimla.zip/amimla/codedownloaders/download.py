from bs4 import BeautifulSoup
import urllib.request
import os

repo = []
language = 'Python'
keyword = 'Keras'
type = 'Repositories'
priority = 'stars'
for i in range(1, 20):
    quote_page = 'https://github.com/search?l=' + language + '&o=desc&p=' + str(i) + '&q=' + keyword + '&s=' + priority + '&type=' + type
    page = urllib.request.urlopen(quote_page)
    soup = BeautifulSoup(page, 'html.parser')
    name_box = soup.find_all('div', attrs={'class': 'repo-list-item d-flex flex-justify-start py-4 public source'})
    for i in range(len(name_box)):
        name = name_box[i].a["href"]  # strip() is used to remove starting and trailing
        repo.append('https://github.com' + name)
for i in range(len(repo)):
    os.system("git clone " + repo[i])
print(repo)
