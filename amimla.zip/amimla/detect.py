#
# Step 1 : Get the network from the source code/ Or the call sequence of the API
#
import ast
import json
from pprint import pprint
import sys

import copy

from queue import PriorityQueue

#
# Step 2: Check with already present API call sequence
#


#
# Step 3: Check if the call sequence match with existing sequence of the API
#


#
# 
#
class bcolors:
    HEADER = '\033[95m'
    OKBLUE = '\033[94m'
    OKGREEN = '\033[92m'
    WARNING = '\033[93m'
    FAIL = '\033[91m'
    ENDC = '\033[0m'
    BOLD = '\033[1m'
    UNDERLINE = '\033[4m'


class Detector:
    def __init__(self, code=None, file=None):
        self.code = code
        self.callseq = None
        self.lines = []
        self.detected = {}
        self.detectcount = 0
        self.file = file
        self.nonmatches = []
        self.apipath = None
        if file != None:
            self.readCode(file)

    def readCode(self, file):
        F = open(file, "rb")
        self.lines = F.readlines()
        self.code = ""
        for l in self.lines:
            self.code += l.decode("utf-8")
            # print(len(self.lines))

    def getAST(self):
        # print(self.code)
        try:
            node = ast.parse(self.code)
        except Exception as e:
            print(sys.exc_info()[1])
            lineno = sys.exc_info()[1].args[1][1]
            # print(len(self.lines))
            # print(self.lines[lineno])
            print("evaluating only code bfore this")
            self.code = ""
            for i in range(0, lineno - 1):
                self.code += self.lines[i].decode("utf-8")
            return ast.parse(self.code)
        return node

    def readAPISequence(self, api=None, filename=None):
        self.apipath = filename
        with open(filename) as f:
            self.callseq = json.load(f)
        # print(self.callseq)

    def getResult(self):
        return {"res": self.detected, "count": self.detectcount,"filename":self.file,"nonmatches":self.nonmatches}

    def matchmetric(self,ob1, ob2):
        total_match = 0
        total = 0
        for key1 in ob1:
            for key2 in ob2:
                if key1 == key2 and ob1[key1] == ob2[key2]:
                    total_match += 1
                # How to handle tuple cases
        
        total = len(ob1) + len(ob2) - total_match
        if total == 0 :
            if len(ob1) == len(ob2):
                return 1
            else:
                return 0
        print(total, total_match, "mathmetric")
        return total_match / total        
    # Checking the similarity
    def check(self, apics,apikey = None):
        # print(self.callseq)
        self.detectcount = 0
        
        self.nonmatches = []
        
        apidef = apics[apikey]
        apitemp = copy.deepcopy(apics)
        apidef.pop('apiname',None)
        apidef.pop('lineno',None)
        apidef.pop('statement',None)
        #print("printing api",apics)
        print("printing callseq", self.callseq)
        #print(apidef in self.callseq)
        messageList = []
        matches = {}
        for cs in apics:
            print("entering here? Line 111 detect.py")
            ok = False
            entered = False
            
            seq = apics[cs]
            for gu in self.callseq:
                entered = True
                # if not ok:
                #   break
                #print("gu", gu)
                print("entering here? Line 121 detect.py")
                match = self.matchmetric(seq,gu)
                #print(match, "MATCH")
                if match in matches:
                    if (seq,gu) not in matches[match]:
                        matches[match].append((seq,gu))
                    if match == 1:
                        ok = True
                        break
                else:
                    matches[match] = []
                    matches[match].append((seq,gu))
                    if match == 1:
                        ok = True
                        break
                #print(matches,"Matches")
                """
                for guk in gu:
                    # print(guk)
                    ics = gu[guk]
                    #print(ics)
                    for key in seq:
                        if key in ics:
                            ok = type(seq[key]) == type(ics[key])
                            if isinstance(seq[key], str):
                                ok = ok and seq[key] == ics[key]
                            elif len(seq[key]) != len(ics[key]):
                                ok = False
                            if not ok:
                                print("Expected a {0} But found {1} at {2}".format(ics[key], seq[key], key))
                                break
                        else:
                            msg = "bla bla"
                            messageList.append(msg)
                        if isinstance(seq[key], str):
                            print('STR KEY',key,seq[key])
                        else:
                            print("NON STR KEY",key, seq[key])
                """

            if ok and entered:
                print(seq, 'Looks ok')
            else:
                print(seq, 'violates from mined patterns')
                max = -1
                mmatch = {}
                for m in matches:
                    if m > max:
                        max = m
                        if len(matches[m]) > 1:
                            print("HI. DONT FORGET TO HANDLE THIS CASE",matches[m],m)
                        mmatch = matches[m][0][1]
                
                print("MAX MATCH ",mmatch, max)
                for k in seq:
                    if k not in mmatch:
                        msg = "There is no key {0} in the good patterns. Refer to DOC".format(k)
                        self.nonmatches.append(msg)
                if mmatch != None:
                    for k in mmatch:
                        if k not in seq:
                            msg = "The maximum match is with pattern {0}. You call doesn't contain the {1} keyword or argument from this pattern. Refer to DOC".format(mmatch,k)
                            self.nonmatches.append(msg)
                #self.detected['nonmatches'] = nonmatchs
                self.detectcount += 1
                if self.file not in self.detected:
                    self.detected[self.file] = []
                self.detected[self.file].append(seq)
            
        
        apics = copy.deepcopy(apitemp)



