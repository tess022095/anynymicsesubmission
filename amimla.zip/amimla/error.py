
class Error:
    def __init__(self,filepath = None,message = None):
        self.filepath = filepath
        self.message = message
    
    def __str__(self):
        return "Error in file {0} and the error message is {1}".format(self.filepath    , self.message)
    